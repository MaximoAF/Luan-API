import { useState } from 'react';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { fmt } from '../utils/format';
import type { Perfume } from '../types';

interface OffersPanelProps {
  perfumes: Perfume[];
  reload: () => void;
}

export default function OffersPanel({ perfumes, reload }: OffersPanelProps) {
  const { token } = useAuth();
  const [busyId, setBusyId] = useState<number | null>(null);
  const active = perfumes.filter((p) => p.offerPrice);

  async function removeOffer(id: number) {
    setBusyId(id);
    try {
      await api.updatePerfume(id, { offerPrice: null }, token);
      reload();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section className="admin-panel active">
      <div className="panel-header">
        <h2>Ofertas</h2>
        <span className="panel-hint">Para aplicar una oferta nueva, andá a Inventario → Editar</span>
      </div>

      {active.length === 0 ? (
        <p className="empty-msg">No hay ofertas activas todavía.</p>
      ) : (
        <div className="offers-grid">
          {active.map((p) => {
            const discount = Math.round((1 - (p.offerPrice as number) / p.price) * 100);
            return (
              <div key={p.id} className="offer-card">
                <div className="top">
                  <h4>{p.name}</h4>
                  <span className="discount">-{discount}%</span>
                </div>
                <div className="prices">
                  <span className="before">{fmt(p.price)}</span>
                  <span className="now">{fmt(p.offerPrice as number)}</span>
                </div>
                <div className="offer-meta">{p.sku} · {p.family}</div>
                <button
                  className="remove-offer"
                  onClick={() => removeOffer(p.id)}
                  disabled={busyId === p.id}
                >
                  {busyId === p.id ? 'Quitando…' : 'Quitar oferta'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
